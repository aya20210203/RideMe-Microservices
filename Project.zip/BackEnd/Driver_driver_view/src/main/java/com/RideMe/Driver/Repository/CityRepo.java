package com.RideMe.Driver.Repository;

import com.RideMe.Driver.Model.City;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CityRepo extends JpaRepository<City, Integer> {

}
