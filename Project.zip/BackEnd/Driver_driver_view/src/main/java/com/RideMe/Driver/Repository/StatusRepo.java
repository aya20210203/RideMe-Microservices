package com.RideMe.Driver.Repository;

import com.RideMe.Driver.Model.Status;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StatusRepo extends JpaRepository<Status, Integer> {

}
