package com.RideMe.Passenger.Repository;

import com.RideMe.Passenger.Model.Status;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StatusRepo extends JpaRepository<Status, Integer> {

}
