package com.RideMe.Rides;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RidesApplicationTests {

	@Test
	void contextLoads() {
	}

}
