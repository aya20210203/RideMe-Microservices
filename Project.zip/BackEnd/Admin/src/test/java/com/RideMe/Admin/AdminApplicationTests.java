package com.RideMe.Admin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.EnableAspectJAutoProxy;


@SpringBootTest
class AdminApplicationTests {

	@Test
	void contextLoads() {
	}

}
